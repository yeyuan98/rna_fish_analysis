function imgExt = getAllowedImageFormatExtensions()
% supported file extensions
imgExt = {'.tif','.TIF','.tiff','.TIFF'};
end

